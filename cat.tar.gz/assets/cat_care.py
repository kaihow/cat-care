"""Pawfect Care - a pygame virtual pet cat game.

Flow: pick one of 5 cats -> pay by solving "x + y = z" (find x)
-> buy food by picking the meal with the biggest hidden x
-> feed / sleep / stroke (1 paw token each) -> earn tokens via math.
"""
import asyncio
import json
import math
import os
import random
import sys

import pygame

W, H = 960, 620
FPS = 60

# ---------------- palette ----------------
BG      = (246, 240, 228)
PANEL   = (255, 253, 248)
INK     = (72, 62, 58)
SOFT    = (152, 140, 132)
BORDER  = (214, 202, 188)
PINK    = (228, 122, 142)
PINK_D  = (198, 88, 112)
GREEN   = (116, 176, 106)
GREEN_D = (76, 138, 70)
RED     = (214, 92, 92)
RED_D   = (178, 66, 66)
GOLD    = (236, 184, 84)
SKY     = (186, 219, 240)
BOWL    = (158, 108, 74)
KIBBLE  = (120, 78, 48)

CATS = [
    # name, label, body color, pattern
    ("Luna",   "White",          (252, 252, 252), "plain"),
    ("Cosmos", "Spotted Gray",   (162, 170, 180), "spots"),
    ("Opal",   "Black",          (52, 48, 56),    "plain"),
    ("Lily",   "Orange Striped", (235, 152, 72),  "stripes"),
    ("Pearl",  "White",          (250, 244, 230), "plain"),
]

MATH_TYPES = [
    ("Find x in:  x + y = z\nx, y, z are 1-20", 1, "x"),
    ("Find y in:  x + y = z\nx is 1-10, sum is 1-20", 2, "y"),
    ("Find y in:\nx + y = z   and   x - y = d", 4, "y"),
    ("Find x in:  x / 2 = r\nr is 1-8", 3, "x"),
]

# ---------------- equation generators ----------------

def make_pay_eq():
    """x + y = z with x,y in 1..9 and z in 10..18. Solve for x."""
    x, y = random.randint(1, 9), random.randint(1, 9)
    while x + y < 10:
        x, y = random.randint(1, 9), random.randint(1, 9)
    return x, y, x + y


def make_food_eqs():
    """5 meals, each 'x + y = z' with y,z in 1..9 and unique hidden x."""
    while True:
        eqs, xs = [], set()
        for _ in range(5):
            z = random.randint(2, 9)
            y = random.randint(1, z - 1)
            eqs.append((z - y, y, z))
            xs.add(z - y)
        if len(xs) == 5:
            return eqs


def make_math_eq(kind):
    """Return (display_lines, answer) for a token equation of given kind."""
    if kind == 0:
        y = random.randint(1, 19)
        x = random.randint(1, 20 - y)
        return ["x + %d = %d" % (y, x + y)], x
    if kind == 1:
        x = random.randint(1, 10)
        y = random.randint(1, 20 - x)
        return ["%d + y = %d" % (x, x + y)], y
    if kind == 2:
        y = random.randint(1, 9)
        d = random.randint(1, 20 - 2 * y)
        x = y + d
        return ["x + y = %d" % (x + y), "x - y = %d" % d], y
    r = random.randint(1, 8)
    return ["x / 2 = %d" % r], 2 * r


# ---------------- save game ----------------

SAVE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "pawfect_save.json")


def save_game(data):
    with open(SAVE_PATH, "w") as f:
        json.dump(data, f, indent=2)


def load_game():
    try:
        with open(SAVE_PATH) as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def has_save():
    return os.path.exists(SAVE_PATH)


# ---------------- sound effects ----------------
# Standard-library PCM synthesis: no NumPy dependency or wheel download.
# Audio initialization is deferred until the first user action to satisfy
# browser autoplay policies. If audio isn't supported, gameplay keeps working.
from array import array

MIX_SR = 22050
SOUNDS = {}
_AUDIO_READY = False
_AUDIO_FAILED = False


def _synthesize(name, sample_rate, channels):
    # Each event is (start_seconds, frequency, duration, loudness).
    tunes = {
        "click": [(0, 900, .055, .35)],
        "correct": [(0, 659, .18, .40), (.12, 880, .29, .45)],
        "wrong": [(0, 220, .35, .35), (0, 185, .35, .30)],
        "coin": [(0, 988, .09, .45), (.07, 1319, .29, .43)],
        "meow": [(0, 540, .42, .40)],
        "purr": [(0, 95, .65, .36)],
        "eat": [(0, 150, .07, .25), (.15, 170, .07, .25), (.30, 130, .07, .25)],
        "sleep": [(0, 330, .55, .38)],
        "power": [(i*.09, f, .25, .37) for i, f in enumerate((392, 523, 659, 784))],
        "gameover": [(i*.25, f, .39, .35) for i, f in enumerate((330, 262, 220, 165))],
        "win": [(i*.12, f, .34, .36) for i, f in enumerate((523, 659, 784, 1047))]
               + [(.5, 1047, .42, .35)],
    }
    events = tunes[name]
    length = int((max(start + duration for start, _, duration, _ in events) + .02) * sample_rate)
    pcm = array("h", [0]) * length
    for start, freq, duration, volume in events:
        start_sample = int(start * sample_rate)
        count = int(duration * sample_rate)
        for j in range(count):
            t = j / sample_rate
            attack = min(1.0, t / .012)
            decay = (1.0 - t / duration) ** 1.8
            f = freq
            if name == "meow":
                f *= 1.0 + .4 * math.sin(math.pi * t / duration)
            elif name == "sleep":
                f *= 1.0 - .55 * t / duration
            tremolo = (.65 + .35 * math.sin(2 * math.pi * 24 * t)) if name == "purr" else 1.0
            harmonic = math.sin(2 * math.pi * f * t) + .22 * math.sin(4 * math.pi * f * t)
            sample = harmonic * volume * attack * decay * tremolo * 22000
            i = start_sample + j
            pcm[i] = max(-32768, min(32767, pcm[i] + int(sample)))
    # 'array' uses native endian (little endian on browser/desktop platforms).
    if channels == 2:
        stereo = array("h")
        for v in pcm:
            stereo.extend((v, v))
        return stereo.tobytes()
    return pcm.tobytes()


def init_sounds():
    # Defer actual mixer initialization until a click, not Game().__init__.
    return


def sfx(name):
    global _AUDIO_READY, _AUDIO_FAILED
    if _AUDIO_FAILED:
        return
    if not _AUDIO_READY:
        try:
            if not pygame.mixer.get_init():
                pygame.mixer.init(frequency=MIX_SR, size=-16, channels=2, buffer=512)
            config = pygame.mixer.get_init()
            if not config or config[1] != -16 or config[2] not in (1, 2):
                _AUDIO_FAILED = True
                print("Pawfect Care audio: unsupported mixer format", config, flush=True)
                return
            freq, _fmt, channels = config
            for key in ("click", "correct", "wrong", "coin", "meow", "purr",
                        "eat", "sleep", "power", "gameover", "win"):
                SOUNDS[key] = pygame.mixer.Sound(buffer=_synthesize(key, freq, channels))
            _AUDIO_READY = True
            print("Pawfect Care audio: mixer initialized", config, flush=True)
        except Exception as exc:
            _AUDIO_FAILED = True
            print("Pawfect Care audio unavailable:", repr(exc), flush=True)
            return
    sound = SOUNDS.get(name)
    if sound:
        try:
            sound.play()
        except pygame.error as exc:
            print("Pawfect Care audio playback error:", repr(exc), flush=True)


# ---------------- small draw helpers ----------------

def darken(color, f):
    return tuple(max(0, int(c * f)) for c in color)


def lighten(color, f):
    return tuple(min(255, int(c + (255 - c) * f)) for c in color)


_font_cache = {}

def font(size):
    if size not in _font_cache:
        _font_cache[size] = pygame.font.Font(None, size)
    return _font_cache[size]


_HAND_PATHS = ("/usr/share/fonts/truetype/msttcorefonts/comic.ttf",
               "/usr/share/fonts/truetype/msttcorefonts/Comic_Sans_MS.ttf")
_hand_cache = {}

def hand_font(size):
    if size not in _hand_cache:
        for p in _HAND_PATHS:
            if os.path.isfile(p):
                _hand_cache[size] = pygame.font.Font(p, size)
                break
        else:
            f = pygame.font.Font(None, size)
            f.set_italic(True)
            _hand_cache[size] = f
    return _hand_cache[size]


def rpanel(surf, rect, color=PANEL, border=BORDER, radius=14, width=2):
    pygame.draw.rect(surf, color, rect, border_radius=radius)
    if border:
        pygame.draw.rect(surf, border, rect, width=width, border_radius=radius)


def draw_paw(surf, x, y, s=1.0, color=GOLD):
    pygame.draw.circle(surf, color, (int(x), int(y + 5 * s)), max(1, int(8 * s)))
    for dx, dy in ((-9, -3), (-3.5, -8), (3.5, -8), (9, -3)):
        pygame.draw.circle(surf, color, (int(x + dx * s), int(y + dy * s)), max(1, int(3.6 * s)))


def draw_heart(surf, x, y, s, color):
    r = max(1, int(3 * s))
    pygame.draw.circle(surf, color, (int(x - 3 * s), int(y - 1 * s)), r)
    pygame.draw.circle(surf, color, (int(x + 3 * s), int(y - 1 * s)), r)
    pygame.draw.polygon(surf, color,
                        [(x - 5.6 * s, y), (x + 5.6 * s, y), (x, y + 6.5 * s)])


def draw_bowl(surf, cx, cy, s=1.0):
    pygame.draw.ellipse(surf, BOWL, pygame.Rect(int(cx - 26 * s), int(cy), int(52 * s), int(20 * s)))
    pygame.draw.ellipse(surf, darken(BOWL, 0.75), pygame.Rect(int(cx - 26 * s), int(cy), int(52 * s), int(20 * s)), max(1, int(2 * s)))
    for dx in (-12, 0, 12):
        pygame.draw.circle(surf, KIBBLE, (int(cx + dx * s), int(cy + 2 * s)), max(1, int(4.5 * s)))


# ---------------- cat drawing ----------------

def draw_cat(surf, cx, cy, s, color, pattern, mode, t, blink):
    """Sitting cat. (cx, cy) is chest reference, s is scale, mode:
    idle | sleeping | eating | stroking | sad | happy"""
    dark = darken(color, 0.62)
    outline = darken(color, 0.45)
    line_c = (45, 40, 44)
    dark_cat = sum(color) < 210
    if dark_cat:
        eye_c, pupil_c = (240, 236, 228), (50, 46, 52)
    else:
        eye_c, pupil_c = (45, 40, 44), (45, 40, 44)

    if mode == "eating":
        bob = abs(math.sin(t * 9)) * 5 * s
    elif mode == "walking":
        bob = abs(math.sin(t * 7)) * 3.5 * s
    else:
        bob = 0
    if mode in ("idle", "stroking"):
        sway = math.sin(t * 1.6) * 1.6 * s + math.sin(t * 0.47 + 1.0) * 1.2 * s
    else:
        sway = 0
    head_dip = {"sleeping": 9, "eating": 6, "sad": 5, "dead": 14}.get(mode, 0) * s
    if mode == "sleeping":
        breath_f, breath_a = 0.28, 1.0
    elif mode == "sad":
        breath_f, breath_a = 0.40, 0.7
    elif mode == "dead":
        breath_f, breath_a = 0.0, 0.0
    else:
        breath_f, breath_a = 0.45, 0.8
    breath = math.sin(t * breath_f * 2 * math.pi) * breath_a
    hx = cx + sway
    hy = cy - 30 * s - bob + head_dip - breath * 1.5 * s

    # tail - whip-like swish with phase lag
    if mode == "sleeping":
        wag, tf = 0.2, 0.8
    elif mode == "walking":
        wag, tf = 0.5, 5.0
    elif mode in ("sad", "dead"):
        wag, tf = 0.0, 0.0
    elif mode == "stroking":
        wag, tf = 1.0, 4.6
    else:
        wag, tf = 0.8, 2.2
    drift = math.sin(t * 0.6) * 0.25
    p0 = (cx + 46 * s, cy + 52 * s)
    if mode in ("sad", "dead"):
        tail_pts = [p0, (cx + 76 * s, cy + 60 * s), (cx + 90 * s, cy + 74 * s),
                    (cx + 102 * s, cy + 80 * s)]
    else:
        w1 = math.sin(t * tf) * wag + drift
        w2 = math.sin(t * tf - 1.0) * wag + drift
        w3 = math.sin(t * tf - 2.0) * wag + drift
        tail_pts = [p0,
                    (cx + 74 * s, cy + 40 * s - 8 * s * w1),
                    (cx + 84 * s, cy + 8 * s - 20 * s * w2),
                    (cx + 90 * s, cy - 10 * s - 32 * s * w3)]
    pygame.draw.lines(surf, color, False, tail_pts, max(2, int(9 * s)))
    pygame.draw.circle(surf, color, (int(tail_pts[-1][0]), int(tail_pts[-1][1])),
                       max(1, int(5 * s)))

    # body - breathes (chest rises, belly stays planted)
    body = pygame.Rect(0, 0, int((104 + 3 * breath) * s), int((76 + 6 * breath) * s))
    body.midbottom = (int(cx), int(cy + 84 * s))
    pygame.draw.ellipse(surf, color, body)
    pygame.draw.ellipse(surf, outline, body, max(1, int(2 * s)))

    # paws - knead while eating
    for i, px in enumerate((-26, -1, 24)):
        paw_dy = -abs(math.sin(t * 9 + i * 1.1)) * 6 * s if mode == "eating" else 0
        r = pygame.Rect(0, 0, int(24 * s), int(14 * s))
        r.center = (int(cx + px * s), int(cy + 80 * s + paw_dy))
        pygame.draw.ellipse(surf, lighten(color, 0.25), r)

    # pattern (body part)
    if pattern == "spots":
        for dx, dy, rr in ((-24, 38, 11), (14, 56, 8), (34, 34, 7)):
            pygame.draw.circle(surf, dark, (int(cx + dx * s), int(cy + dy * s)), max(1, int(rr * s)))
    if pattern == "stripes":
        for x0 in (-28, -8, 12, 32):
            pygame.draw.line(surf, dark,
                             (cx + x0 * s, cy + 22 * s), (cx + (x0 - 8) * s, cy + 62 * s),
                             max(2, int(5 * s)))

    # ears - occasional twitch, droop when sad
    def ear_twitch(off, period):
        ph = (t + off) % period
        if ph < 0.22:
            return math.sin(ph / 0.22 * math.pi)
        return 0.0

    twl, twr = ear_twitch(1.3, 6.7), ear_twitch(4.1, 8.9)
    if mode in ("sad", "dead"):
        ear_l = [(hx - 34 * s, hy - 46 * s), (hx - 13 * s, hy - 77 * s), (hx - 9 * s, hy - 64 * s)]
        ear_r = [(hx + 34 * s, hy - 46 * s), (hx + 13 * s, hy - 77 * s), (hx + 9 * s, hy - 64 * s)]
    else:
        ear_l = [(hx - 34 * s, hy - 46 * s),
                 (hx - 24 * s - 5 * s * twl, hy - 86 * s - 4 * s * twl),
                 (hx - 4 * s, hy - 62 * s)]
        ear_r = [(hx + 34 * s, hy - 46 * s),
                 (hx + 24 * s + 5 * s * twr, hy - 86 * s - 4 * s * twr),
                 (hx + 4 * s, hy - 62 * s)]
    pygame.draw.polygon(surf, color, ear_l)
    pygame.draw.polygon(surf, color, ear_r)
    pygame.draw.polygon(surf, outline, ear_l, max(1, int(2 * s)))
    pygame.draw.polygon(surf, outline, ear_r, max(1, int(2 * s)))

    # head
    head_r = max(2, int(40 * s))
    pygame.draw.circle(surf, color, (int(hx), int(hy)), head_r)
    pygame.draw.circle(surf, outline, (int(hx), int(hy)), head_r, max(1, int(2 * s)))
    pygame.draw.polygon(surf, (232, 168, 176),
                        [(hx - 29 * s, hy - 49 * s), (hx - 24 * s, hy - 74 * s), (hx - 11 * s, hy - 57 * s)])
    pygame.draw.polygon(surf, (232, 168, 176),
                        [(hx + 29 * s, hy - 49 * s), (hx + 24 * s, hy - 74 * s), (hx + 11 * s, hy - 57 * s)])

    # pattern (head part)
    if pattern == "spots":
        for dx, dy, rr in ((8, -44, 6), (-18, -22, 5)):
            pygame.draw.circle(surf, dark, (int(hx + dx * s), int(hy + dy * s)), max(1, int(rr * s)))
    if pattern == "stripes":
        for x0, slant in ((-14, 3), (0, 0), (14, -3)):
            pygame.draw.line(surf, dark,
                             (hx + x0 * s, hy - 38 * s), (hx + (x0 + slant) * s, hy - 16 * s),
                             max(2, int(5 * s)))

    # eyes
    eye_l = (int(hx - 15 * s), int(hy - 6 * s))
    eye_r = (int(hx + 15 * s), int(hy - 6 * s))
    closed = blink or mode == "sleeping"
    if mode == "stroking":
        for ex, ey in (eye_l, eye_r):
            pygame.draw.lines(surf, line_c, False,
                              [(ex - 6 * s, ey + 2 * s), (ex, ey - 5 * s), (ex + 6 * s, ey + 2 * s)],
                              max(2, int(2.5 * s)))
    elif closed:
        for ex, ey in (eye_l, eye_r):
            pygame.draw.line(surf, line_c, (ex - 6 * s, ey), (ex + 6 * s, ey), max(2, int(2.5 * s)))
    elif mode == "dead":
        for ex, ey in (eye_l, eye_r):
            pygame.draw.line(surf, line_c, (ex - 5 * s, ey - 5 * s), (ex + 5 * s, ey + 5 * s), max(2, int(2.5 * s)))
            pygame.draw.line(surf, line_c, (ex - 5 * s, ey + 5 * s), (ex + 5 * s, ey - 5 * s), max(2, int(2.5 * s)))
    elif mode == "sad":
        for ex, ey in (eye_l, eye_r):
            pygame.draw.circle(surf, eye_c, (ex, ey), max(1, int(4.5 * s)))
            if dark_cat:
                pygame.draw.circle(surf, pupil_c, (ex, ey + 1 * s), max(1, int(2 * s)))
            pygame.draw.line(surf, lighten(color, 0.3),
                             (ex - 7 * s, ey - 7 * s), (ex + 7 * s, ey - 4 * s), max(1, int(2 * s)))
    else:
        for ex, ey in (eye_l, eye_r):
            if dark_cat:
                pygame.draw.circle(surf, eye_c, (ex, ey), max(1, int(5 * s)))
                pygame.draw.circle(surf, pupil_c, (ex, ey), max(1, int(2.6 * s)))
            else:
                pygame.draw.circle(surf, eye_c, (ex, ey), max(1, int(5 * s)))
                pygame.draw.circle(surf, (255, 255, 255),
                                   (ex + int(1.5 * s), ey - int(1.5 * s)), max(1, int(1.6 * s)))

    # nose + mouth
    pygame.draw.polygon(surf, (214, 128, 142),
                        [(hx - 4 * s, hy + 10 * s), (hx + 4 * s, hy + 10 * s), (hx, hy + 16 * s)])
    if mode == "eating":
        open_amt = 2 * s + abs(math.sin(t * 9)) * 4 * s
        pygame.draw.ellipse(surf, line_c,
                            pygame.Rect(int(hx - 5 * s), int(hy + 16 * s), int(10 * s), int(open_amt)))
    else:
        for mx in (-4, 4):
            r = pygame.Rect(0, 0, int(7 * s), int(7 * s))
            r.center = (int(hx + mx * s), int(hy + 19 * s))
            pygame.draw.arc(surf, (90, 78, 72), r, math.pi * 0.15, math.pi * 0.85, max(1, int(1.6 * s)))

    # whiskers
    for side in (-1, 1):
        for dy, slant in ((8, -4), (12, 0), (16, 4)):
            pygame.draw.line(surf, (120, 110, 105),
                             (hx + side * 20 * s, hy + dy * s),
                             (hx + side * 40 * s, hy + (dy + slant * side) * s), 1)

    # collar
    pygame.draw.line(surf, PINK_D,
                     (hx - 22 * s, hy + 26 * s), (hx + 22 * s, hy + 26 * s),
                     max(2, int(6 * s)))
    pygame.draw.circle(surf, GOLD, (int(hx), int(hy + 32 * s)), max(1, int(4.5 * s)))


# ---------------- UI ----------------

class Button:
    def __init__(self, x, y, w, h, label, fs=26, bg=PANEL, fg=INK, border=BORDER):
        self.rect = pygame.Rect(x, y, w, h)
        self.label, self.fs = label, fs
        self.bg, self.fg, self.border = bg, fg, border

    def draw(self, surf, enabled=True, hovered=False):
        if not enabled:
            rpanel(surf, self.rect, (232, 226, 216), (204, 196, 186), radius=12)
            t = font(self.fs).render(self.label, True, (168, 160, 152))
        else:
            bg = lighten(self.bg, 0.5) if hovered else self.bg
            rpanel(surf, self.rect, bg, self.border if not hovered else PINK, radius=12,
                   width=3 if hovered else 2)
            t = font(self.fs).render(self.label, True, self.fg)
        surf.blit(t, t.get_rect(center=self.rect.center))

    def clicked(self, pos, down):
        return down and self.rect.collidepoint(pos)


CAT_X, CAT_Y, CAT_S = 290, 355, 1.25
POWER_STEP = 0.16                    # growth per power-up
WIN_POWER_COUNT = 5                  # power-ups needed to win
WIN_SCALE = 1.0 + POWER_STEP * WIN_POWER_COUNT  # grow the cat this big to win
STAT_DECAY = 70.0 / 120.0            # a neglected cat hits 0 in 2 minutes
WALK_SPEED = 260.0                   # px/s, rescued cat strolls in from the left
BOX_FLY_SPEED = 600.0                # px/s, box sails off screen on reveal
BOX_CAT_SCALE = 0.7                  # cat inside the box, small enough to hide

class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((W, H))
        pygame.display.set_caption("Pawfect Care")
        self.clock = pygame.time.Clock()
        init_sounds()
        self.state = "shop"
        self.t = 0.0
        self.paused = False
        self.tokens = 5
        self.servings = 0
        self.cat = None
        self.cat_mode = "idle"
        self.walk_x = None
        self.mode_left = 0.0
        self.stats = {"Fullness": 70.0, "Energy": 70.0, "Mood": 70.0}
        self.blink_left = random.uniform(1.5, 3.5)
        self.blinking = 0.0
        self.particles = []
        self.msg, self.msg_color, self.msg_left = "", INK, 0.0
        self.input_text = ""
        self.focus_input = False
        self.pay_eq = None
        self.food_eqs = None
        self.math_kind = None
        self.math_eq = None
        self.cat_scale = 1.0
        self.power_count = 0
        self.power_up = False
        self.power_window = -1
        self.power_offsets = []
        self.power_fired = 0
        self.math_tries = 0
        self.pay_tries = 0
        self.food_tries = 0
        self.end_reason = ""
        # layout
        self.shop_rects = [pygame.Rect(30 + i * 186, 170, 170, 330) for i in range(5)]
        self.food_rects = [pygame.Rect(30 + i * 186, 190, 170, 250) for i in range(5)]
        self.btn_pay = Button(430, 420, 170, 54, "Pay")
        self.btn_feed = Button(600, 268, 300, 52, "Feed  (-1 paw)")
        self.btn_sleep = Button(600, 332, 300, 52, "Sleep  (-1 paw)")
        self.btn_stroke = Button(600, 396, 300, 52, "Stroke  (-1 paw)")
        self.btn_earn = Button(600, 472, 300, 52, "Earn Paw Tokens", bg=(250, 236, 200), fg=(140, 100, 30))
        self.btn_food = Button(600, 536, 300, 44, "Buy Food  (-3 paws)", fs=22)
        self.btn_submit = Button(330, 470, 150, 50, "Submit")
        self.btn_back = Button(780, 50, 140, 48, "Back")
        self.math_rects = [pygame.Rect(60 + (i % 2) * 430, 120 + (i // 2) * 190, 400, 160)
                           for i in range(4)]
        self.btn_load = Button(670, 26, 128, 46, "Load", fs=22)
        self.btn_new = Button(808, 26, 128, 46, "New Game", fs=22)
        self.btn_psave = Button(40, 14, 96, 40, "Save", fs=20)
        self.btn_pload = Button(144, 14, 96, 40, "Load", fs=20)
        self.btn_pnew = Button(248, 14, 110, 40, "New Game", fs=20)
        self.btn_power = Button(305, 486, 190, 48, "Power Up!", bg=(250, 236, 200), fg=(140, 100, 30))
        self.box_rect = pygame.Rect(0, 0, 240, 195)
        self.box_rect.center = (W // 2, 360)
        self.bowl_rect = pygame.Rect(0, 0, 180, 110)
        self.bowl_rect.center = (720, 430)
        self.box_alive = False
        self.box_flying = False
        self.box_x = None
        self.reveal_left = 0.0

    # ---------- helpers ----------

    def say(self, text, color=INK):
        self.msg, self.msg_color, self.msg_left = text, color, 3.2

    def set_mode(self, m):
        self.cat_mode = m
        if m == "eating":
            self.mode_left = 2.5
        elif m == "sleeping":
            self.mode_left = 5.0
        elif m == "stroking":
            self.mode_left = 2.5

    # ---------- events ----------

    def handle_event(self, e):
        if e.type == pygame.QUIT:
            return False
        if e.type == pygame.KEYDOWN and e.key == pygame.K_SPACE:
            self.paused = not self.paused
            return True
        if self.paused:
            return True
        if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
            self.click(e.pos)
        elif e.type == pygame.TEXTINPUT and self.focus_input:
            for ch in e.text:
                if ch.isdigit() and len(self.input_text) < 3:
                    self.input_text += ch
        elif e.type == pygame.KEYDOWN:
            if e.key == pygame.K_RETURN and self.focus_input:
                self.submit_input()
            elif e.key == pygame.K_BACKSPACE and self.focus_input:
                self.input_text = self.input_text[:-1]
        return True

    def click(self, pos):
        if self.paused:
            return
        sfx("click")
        if self.state == "win":
            if self.btn_load.clicked(pos, True):
                self.do_load()
            elif self.btn_new.clicked(pos, True):
                self.do_new()
        elif self.state == "gameover":
            if not self.box_flying and self.reveal_left <= 0 and self.box_rect.collidepoint(pos):
                self.box_flying = True
                self.box_x = self.box_rect.centerx
                sfx("meow" if self.box_alive else "gameover")
        elif self.state == "dead":
            if self.btn_new.clicked(pos, True):
                self.do_new()
        elif self.state == "shop":
            if self.btn_load.clicked(pos, True):
                self.do_load()
                return
            if self.btn_new.clicked(pos, True):
                self.do_new()
                return
            for i, r in enumerate(self.shop_rects):
                if r.collidepoint(pos):
                    self.cat = CATS[i]
                    self.pay_eq = make_pay_eq()
                    self.pay_tries = 0
                    self.input_text = ""
                    self.focus_input = True
                    self.state = "pay"
                    self.say("Solve the equation to pay for %s." % self.cat[0])
                    break
        elif self.state == "pay":
            if self.btn_pay.clicked(pos, True):
                self.submit_input()
        elif self.state == "food":
            for i, r in enumerate(self.food_rects):
                if r.collidepoint(pos):
                    self.pick_food(i)
                    break
        elif self.state == "pet":
            busy = self.cat_mode not in ("idle", "sad")
            if self.btn_psave.clicked(pos, True):
                self.do_save()
            elif self.btn_pload.clicked(pos, True):
                self.do_load()
            elif self.btn_pnew.clicked(pos, True):
                self.do_new()
            elif self.btn_power.clicked(pos, True) and self.power_up:
                self.power_up = False
                self.power_count += 1
                sfx("power")
                self.cat_scale = min(WIN_SCALE, 1.0 + POWER_STEP * self.power_count)
                left = WIN_POWER_COUNT - self.power_count
                self.say("Power up! %s is growing! (%d to go)" % (self.cat[0], left)
                         if left > 0 else "Power up! %s reached full size!" % self.cat[0], GREEN_D)
            elif self.btn_feed.clicked(pos, True) and not busy and self.tokens >= 1:
                self.do_feed()
            elif self.btn_sleep.clicked(pos, True) and not busy and self.tokens >= 1:
                self.do_sleep()
            elif self.btn_stroke.clicked(pos, True) and not busy and self.tokens >= 1:
                self.do_stroke()
            elif self.btn_earn.clicked(pos, True):
                self.state = "math"
                self.math_kind = None
                self.math_eq = None
                self.input_text = ""
                self.focus_input = False
            elif self.btn_food.clicked(pos, True):
                if self.tokens < 3:
                    self.say("Not enough paw tokens! Food costs 3.", RED)
                else:
                    self.tokens -= 3
                    self.state = "food"
                    self.food_eqs = make_food_eqs()
                    self.food_tries = 0
                    self.focus_input = False
                    self.say("Buy the meal with the biggest hidden x.")
        elif self.state == "math":
            if self.math_eq is not None:
                if self.btn_submit.clicked(pos, True):
                    self.submit_input()
                elif self.btn_back.clicked(pos, True):
                    self.state = "pet"
                    self.math_eq = None
                    self.focus_input = False
            else:
                for i, r in enumerate(self.math_rects):
                    if r.collidepoint(pos):
                        self.math_kind = i
                        self.math_eq = make_math_eq(i)
                        self.math_tries = 0
                        self.input_text = ""
                        self.focus_input = True
                        break
                if self.btn_back.clicked(pos, True):
                    self.state = "pet"

    def submit_input(self):
        if not self.input_text:
            return
        val = int(self.input_text)
        self.input_text = ""
        if self.state == "pay":
            if val == self.pay_eq[0]:
                self.focus_input = False
                self.state = "food"
                self.food_eqs = make_food_eqs()
                self.food_tries = 0
                sfx("meow")
                self.say("%s is yours! First bag is on the house." % self.cat[0], GREEN_D)
            else:
                self.pay_tries += 1
                if self.pay_tries >= 2:
                    self.game_over("You used up both tries paying for %s." % self.cat[0])
                else:
                    sfx("wrong")
                    self.pay_eq = make_pay_eq()
                    self.say("Not quite - no purchase. 1 try left!", RED)
        elif self.state == "math" and self.math_eq is not None:
            if val == self.math_eq[1]:
                reward = MATH_TYPES[self.math_kind][1]
                self.tokens += reward
                self.math_eq = None
                self.math_tries = 0
                self.focus_input = False
                sfx("coin")
                self.say("Correct! +%d paw token%s." % (reward, "s" if reward != 1 else ""), GREEN_D)
            else:
                self.math_tries += 1
                if self.math_tries >= 2:
                    self.game_over("You used up both tries on a math task.")
                else:
                    sfx("wrong")
                    self.say("Wrong answer - 1 try left!", RED)

    def pick_food(self, i):
        eqs = self.food_eqs
        best = max(e[0] for e in eqs)
        if eqs[i][0] == best:
            self.servings += 5
            sfx("coin")
            self.say("Great deal! +1 food bag (5 servings).", GREEN_D)
            self.state = "pet"
        else:
            self.food_tries += 1
            if self.food_tries >= 2:
                self.game_over("You used up both tries in the food aisle.")
            else:
                sfx("wrong")
                self.food_eqs = make_food_eqs()
                self.say("Not the biggest x! All labels changed. 1 try left!", RED)

    # ---------- save / load / new ----------

    def do_save(self):
        if self.cat is None:
            self.say("Nothing to save yet - adopt a cat first.", RED)
            return
        data = {"cat_index": CATS.index(self.cat), "tokens": self.tokens,
                "servings": self.servings, "stats": self.stats,
                "power_count": self.power_count,
                "cat_scale": self.cat_scale}
        try:
            save_game(data)
            self.say("Game saved!", GREEN_D)
        except OSError:
            self.say("Could not save the game.", RED)

    def do_load(self):
        data = load_game()
        if data is None:
            self.say("No saved game found.", RED)
            return
        idx = data.get("cat_index", 0)
        if not isinstance(idx, int) or not 0 <= idx < len(CATS):
            idx = 0
        self.cat = CATS[idx]
        self.tokens = int(data.get("tokens", 5))
        self.servings = int(data.get("servings", 0))
        stats = {"Fullness": 70.0, "Energy": 70.0, "Mood": 70.0}
        for k, v in data.get("stats", {}).items():
            if k in stats:
                stats[k] = float(v)
        self.stats = stats
        count = data.get("power_count")
        if count is None:
            count = (float(data.get("cat_scale", 1.0)) - 1.0) / POWER_STEP
        self.power_count = max(0, min(WIN_POWER_COUNT, int(round(float(count)))))
        self.cat_scale = min(WIN_SCALE, 1.0 + POWER_STEP * self.power_count)
        self.cat_mode = "idle"
        self.walk_x = None
        self.math_tries = 0
        self.pay_tries = 0
        self.food_tries = 0
        self.end_reason = ""
        self.input_text = ""
        self.focus_input = False
        self.state = "pet"
        self.paused = False
        self.say("Welcome back, %s!" % self.cat[0], GREEN_D)

    def do_new(self):
        self.cat = None
        self.tokens = 5
        self.servings = 0
        self.cat_mode = "idle"
        self.walk_x = None
        self.cat_scale = 1.0
        self.power_count = 0
        self.stats = {"Fullness": 70.0, "Energy": 70.0, "Mood": 70.0}
        self.math_tries = 0
        self.pay_tries = 0
        self.food_tries = 0
        self.end_reason = ""
        self.input_text = ""
        self.focus_input = False
        self.state = "shop"
        self.paused = False
        self.say("A fresh start!", GREEN_D)

    # ---------- game end ----------

    def game_over(self, reason):
        self.state = "gameover"
        self.end_reason = reason
        sfx("gameover")
        self.math_tries = 0
        self.math_eq = None
        self.power_up = False
        self.focus_input = False
        self.cat_mode = "idle"
        self.walk_x = None
        self.box_alive = random.random() < 0.5
        self.box_flying = False
        self.box_x = None
        self.reveal_left = 0.0

    def win(self):
        self.state = "win"
        self.end_reason = "%s grew to full size - you are a master cat caretaker!" % self.cat[0]
        sfx("win")
        self.math_eq = None
        self.power_up = False
        self.focus_input = False
        self.cat_mode = "idle"
        self.walk_x = None



    # ---------- pet actions ----------

    def do_feed(self):
        if self.tokens < 1:
            self.say("Not enough paw tokens! Solve math to earn some.", RED)
            return
        if self.servings <= 0:
            self.say("No food left! Buy a food bag first.", RED)
            return
        self.tokens -= 1
        self.servings -= 1
        self.stats["Fullness"] = min(100.0, self.stats["Fullness"] + 40.0)
        self.set_mode("eating")
        sfx("eat")
        self.say("Nom nom nom...")

    def do_sleep(self):
        if self.tokens < 1:
            self.say("Not enough paw tokens! Solve math to earn some.", RED)
            return
        self.tokens -= 1
        self.set_mode("sleeping")
        sfx("sleep")
        self.say("Shh... zzz")

    def do_stroke(self):
        if self.tokens < 1:
            self.say("Not enough paw tokens! Solve math to earn some.", RED)
            return
        self.tokens -= 1
        self.stats["Mood"] = min(100.0, self.stats["Mood"] + 35.0)
        self.set_mode("stroking")
        sfx("purr")
        self.say("Purrrrrr...")

    # ---------- update ----------

    def update(self, dt):
        if self.paused:
            return
        self.t += dt
        # grow power-up appears twice per 4-minute window, at random times
        win = int(self.t // 240)
        if win != self.power_window:
            self.power_window = win
            self.power_offsets = sorted(random.uniform(0, 240) for _ in range(2))
            self.power_fired = 0
        if self.state == "pet" and not self.power_up:
            off = self.t - win * 240
            while self.power_fired < 2 and off >= self.power_offsets[self.power_fired]:
                self.power_fired += 1
                self.power_up = True
                self.say("A power-up appeared! Click it to make %s grow!" % self.cat[0], GREEN_D)
        elif self.state != "pet" and self.power_up:
            self.power_up = False
        self.blink_left -= dt
        if self.blink_left <= 0:
            self.blinking = 0.15
            self.blink_left = random.uniform(2.0, 4.0)
        if self.blinking > 0:
            self.blinking -= dt
        if self.msg_left > 0:
            self.msg_left -= dt
        for p in self.particles[:]:
            p["y"] += p["vy"] * dt
            p["life"] -= dt
            if p["life"] <= 0:
                self.particles.remove(p)
        if self.state == "gameover":
            if self.box_flying:
                self.box_x -= BOX_FLY_SPEED * dt
                if self.box_x + self.box_rect.w / 2 < 0:
                    self.box_flying = False
                    self.reveal_left = 1.0 if self.box_alive else 1.5
            elif self.reveal_left > 0:
                self.reveal_left -= dt
                if self.reveal_left <= 0:
                    if self.box_alive:
                        self.stats = {"Fullness": 70.0, "Energy": 70.0, "Mood": 70.0}
                        self.cat_mode = "idle"
                        self.state = "pet"
                        self.say("%s is alive! Welcome back!" % self.cat[0], GREEN_D)
                    else:
                        self.state = "dead"
            return
        if self.state not in ("pet", "food", "math"):
            return
        st = self.stats
        if self.power_count >= WIN_POWER_COUNT:
            self.win()
            return
        if self.cat_mode == "sleeping":
            st["Energy"] = min(100.0, st["Energy"] + 12.0 * dt)
            st["Fullness"] = max(0.0, st["Fullness"] - 0.3 * dt * self.cat_scale)
            if st["Fullness"] <= 0.0:
                self.game_over("%s starved while sleeping..." % self.cat[0])
                return
            self.mode_left -= dt
            if random.random() < dt * 1.4:
                self.particles.append({"kind": "z", "x": CAT_X + 70, "y": CAT_Y - 110,
                                       "vy": -22, "life": 2.2,
                                       "s": random.uniform(0.9, 1.8)})
            if self.mode_left <= 0:
                self.set_mode("idle")
                self.say("%s woke up feeling rested!" % self.cat[0], GREEN_D)
            return
        # a neglected cat hits 0 in 2 minutes; a bigger cat even faster
        st["Fullness"] = max(0.0, st["Fullness"] - STAT_DECAY * dt * self.cat_scale)
        st["Energy"] = max(0.0, st["Energy"] - STAT_DECAY * dt * self.cat_scale)
        st["Mood"] = max(0.0, st["Mood"] - STAT_DECAY * dt * self.cat_scale)
        if st["Fullness"] <= 0.0 or st["Energy"] <= 0.0:
            why = "starved" if st["Fullness"] <= 0.0 else "got too tired"
            self.game_over("%s %s and didn't make it..." % (self.cat[0], why))
            return
        if self.cat_mode == "walking":
            self.walk_x = min(CAT_X, self.walk_x + WALK_SPEED * dt)
            self.mode_left -= dt
            if self.walk_x >= CAT_X or self.mode_left <= 0:
                self.walk_x = None
                self.set_mode("idle")
        elif self.cat_mode == "eating":
            self.mode_left -= dt
            if random.random() < dt * 7:
                self.particles.append({"kind": "kibble", "x": CAT_X + random.randint(-30, 30),
                                       "y": CAT_Y - 5, "vy": 60, "life": 0.8, "s": 1.0})
            if self.mode_left <= 0:
                self.set_mode("idle")
        elif self.cat_mode == "stroking":
            self.mode_left -= dt
            if random.random() < dt * 2.5:
                self.particles.append({"kind": "heart", "x": CAT_X + random.randint(-45, 45),
                                       "y": CAT_Y - 70, "vy": -32, "life": 1.6,
                                       "s": random.uniform(0.8, 1.5)})
            if self.mode_left <= 0:
                self.set_mode("idle")
        if self.cat_mode == "idle" and min(st.values()) < 25:
            self.set_mode("sad")
            sfx("meow")
            self.say("%s feels a bit... unwell. Take good care of %s!" % (self.cat[0], self.cat[0]), RED)
        elif self.cat_mode == "sad" and min(st.values()) >= 30:
            self.set_mode("idle")

    def draw_particles(self, surf):
        for p in self.particles:
            if p["kind"] == "heart":
                draw_heart(surf, p["x"], p["y"], p["s"], PINK)
            elif p["kind"] == "z":
                t = font(int(22 * p["s"])).render("Z", True, (130, 140, 190))
                surf.blit(t, (p["x"], p["y"]))
            elif p["kind"] == "kibble":
                pygame.draw.circle(surf, KIBBLE, (int(p["x"]), int(p["y"])), 4)

    # ---------- shared widgets ----------

    def draw_token_hud(self, surf):
        x0 = W - 190
        rpanel(surf, pygame.Rect(x0, 14, 176, 52), PANEL, BORDER, radius=12)
        draw_paw(surf, x0 + 34, 40, 1.5)
        t = font(30).render("%d" % self.tokens, True, INK)
        surf.blit(t, (x0 + 58, 28))
        t = font(20).render("paw tokens", True, SOFT)
        surf.blit(t, (x0 + 100, 32))

    def draw_food_hud(self, surf):
        x0 = W - 420
        rpanel(surf, pygame.Rect(x0, 14, 200, 52), PANEL, BORDER, radius=12)
        draw_bowl(surf, x0 + 30, 34, 0.7)
        t = font(28).render("%d servings" % self.servings, True, INK)
        surf.blit(t, (x0 + 58, 30))

    def draw_message_bar(self, surf):
        if self.msg_left <= 0:
            return
        t = font(26).render(self.msg, True, self.msg_color)
        w = min(t.get_width() + 40, W - 40)
        r = pygame.Rect(0, 0, w, 44)
        r.center = (W // 2, H - 38)
        rpanel(surf, r, (255, 252, 244), self.msg_color, radius=22, width=2)
        surf.blit(t, t.get_rect(center=r.center))

    def draw_input_box(self, surf, x, y, w, h, hint):
        r = pygame.Rect(x, y, w, h)
        rpanel(surf, r, (255, 255, 255), PINK_D if self.focus_input else BORDER, radius=10, width=2)
        caret = "|" if self.focus_input and int(self.t * 2) % 2 == 0 else ""
        txt = self.input_text + caret if self.input_text or caret else ""
        if not txt:
            t = font(30).render(hint, True, (190, 180, 172))
        else:
            t = font(34).render(txt, True, INK)
        surf.blit(t, (x + 16, y + (h - t.get_height()) // 2))

    # ---------- screens ----------

    def draw_shop(self, surf, mouse):
        t = font(56).render("Pawfect Care", True, PINK_D)
        surf.blit(t, t.get_rect(midtop=(W // 2, 24)))
        t = font(28).render("Welcome! Pick one of our five cats to bring home.", True, SOFT)
        surf.blit(t, t.get_rect(midtop=(W // 2, 96)))
        for i, (name, label, color, pattern) in enumerate(CATS):
            r = self.shop_rects[i]
            hovered = r.collidepoint(mouse)
            rpanel(surf, r, PANEL, PINK if hovered else BORDER, radius=16, width=3 if hovered else 2)
            draw_cat(surf, r.centerx, r.y + 165, 0.62, color, pattern, "idle", self.t + i * 1.3, False)
            t = font(32).render(name, True, INK)
            surf.blit(t, t.get_rect(midtop=(r.centerx, r.y + 248)))
            t = font(22).render(label, True, SOFT)
            surf.blit(t, t.get_rect(midtop=(r.centerx, r.y + 284)))
        t = font(24).render("Click a cat to buy it (you will pay by solving a math equation).", True, SOFT)
        surf.blit(t, t.get_rect(midbottom=(W // 2, H - 24)))
        self.btn_load.draw(surf, enabled=has_save(), hovered=self.btn_load.rect.collidepoint(mouse))
        self.btn_new.draw(surf, hovered=self.btn_new.rect.collidepoint(mouse))

    def draw_pay(self, surf, mouse):
        name, label, color, pattern = self.cat
        x, y, z = self.pay_eq
        rpanel(surf, pygame.Rect(40, 70, 380, 480), PANEL, BORDER, radius=18)
        draw_cat(surf, 230, 330, 1.1, color, pattern, "idle", self.t, self.blinking > 0)
        t = font(30).render("Buying %s," % name, True, INK)
        surf.blit(t, t.get_rect(midtop=(230, 110)))
        t = font(24).render("the %s cat" % label, True, SOFT)
        surf.blit(t, t.get_rect(midtop=(230, 144)))
        rpanel(surf, pygame.Rect(450, 70, 470, 480), PANEL, BORDER, radius=18)
        t = font(28).render("Payment - solve for x", True, INK)
        surf.blit(t, t.get_rect(midtop=(685, 100)))
        t = font(72).render("x + %d = %d" % (y, z), True, PINK_D)
        surf.blit(t, t.get_rect(midtop=(685, 160)))
        t = font(24).render("(x and y are 1-9, so z is 10-18)", True, SOFT)
        surf.blit(t, t.get_rect(midtop=(685, 258)))
        self.draw_input_box(surf, 560, 320, 250, 60, "type x here...")
        self.btn_pay.draw(surf, hovered=self.btn_pay.rect.collidepoint(mouse))
        t = font(22).render("Wrong answer = a new equation. You get 2 tries, then game over!", True, SOFT)
        surf.blit(t, t.get_rect(midtop=(685, 500)))
        self.draw_message_bar(surf)

    def draw_food(self, surf, mouse):
        t = font(48).render("The Pet Food Aisle", True, PINK_D)
        surf.blit(t, t.get_rect(midtop=(W // 2, 20)))
        t = font(26).render("Every bag's label hides an x in 'x + y = z'. Buy the bag with the BIGGEST x.", True, SOFT)
        surf.blit(t, t.get_rect(midtop=(W // 2, 84)))
        t = font(22).render("A wrong pick shuffles every label. You get 2 tries, then game over!", True, SOFT)
        surf.blit(t, t.get_rect(midtop=(W // 2, 118)))
        for i, (hx, y, z) in enumerate(self.food_eqs):
            r = self.food_rects[i]
            hovered = r.collidepoint(mouse)
            rpanel(surf, r, PANEL, PINK if hovered else BORDER, radius=16, width=3 if hovered else 2)
            draw_bowl(surf, r.centerx, r.y + 60, 1.1)
            t = font(34).render("x + %d = %d" % (y, z), True, INK)
            surf.blit(t, t.get_rect(midtop=(r.centerx, r.y + 130)))
            t = font(20).render("bag #%d" % (i + 1), True, SOFT)
            surf.blit(t, t.get_rect(midtop=(r.centerx, r.y + 196)))
        self.draw_token_hud(surf)
        self.draw_message_bar(surf)

    def draw_pet(self, surf, mouse):
        name, label, color, pattern = self.cat
        # room
        room = pygame.Rect(40, 70, 530, 510)
        rpanel(surf, room, (250, 246, 238), BORDER, radius=18)
        win = pygame.Rect(80, 110, 130, 100)
        pygame.draw.rect(surf, SKY, win, border_radius=8)
        pygame.draw.rect(surf, (220, 210, 196), win, 3, border_radius=8)
        pygame.draw.line(surf, (220, 210, 196), (win.centerx, win.top), (win.centerx, win.bottom), 3)
        pygame.draw.line(surf, (220, 210, 196), (win.left, win.centery), (win.right, win.centery), 3)
        floor = pygame.Rect(60, 540, 490, 26)
        pygame.draw.ellipse(surf, (226, 214, 198), floor)
        cx = CAT_X if self.walk_x is None else self.walk_x
        draw_cat(surf, cx, CAT_Y, CAT_S * self.cat_scale, color, pattern,
                  self.cat_mode, self.t, self.blinking > 0)
        self.draw_particles(surf)
        t = font(34).render("%s the %s" % (name, label.lower()), True, INK)
        surf.blit(t, t.get_rect(midtop=(room.centerx, 84)))
        # stats panel
        rpanel(surf, pygame.Rect(590, 70, 330, 180), PANEL, BORDER, radius=16)
        t = font(26).render("How is %s doing?" % name, True, INK)
        surf.blit(t, t.get_rect(midtop=(755, 86)))
        bar_y = 130
        for key in ("Fullness", "Energy", "Mood"):
            val = self.stats[key]
            t = font(22).render(key, True, SOFT)
            surf.blit(t, (610, bar_y))
            track = pygame.Rect(700, bar_y + 4, 190, 16)
            pygame.draw.rect(surf, (232, 226, 216), track, border_radius=8)
            fill_w = int(track.w * val / 100.0)
            if fill_w > 4:
                c = GREEN if val >= 50 else (GOLD if val >= 25 else RED)
                pygame.draw.rect(surf, c, pygame.Rect(track.x, track.y, fill_w, track.h), border_radius=8)
            bar_y += 40
        busy = self.cat_mode not in ("idle", "sad")
        no_tokens = self.tokens < 1
        for b in (self.btn_feed, self.btn_sleep, self.btn_stroke):
            b.draw(surf, enabled=not busy and not no_tokens, hovered=b.rect.collidepoint(mouse))
        if no_tokens and not busy:
            t = font(20).render("No paws! Solve math to earn tokens.", True, RED)
            surf.blit(t, t.get_rect(midtop=(750, 224)))
        if self.servings <= 0:
            t = font(20).render("Out of food - buy a bag!", True, RED)
            surf.blit(t, t.get_rect(midtop=(750, 246)))
        self.btn_earn.draw(surf, hovered=self.btn_earn.rect.collidepoint(mouse))
        self.btn_food.draw(surf, hovered=self.btn_food.rect.collidepoint(mouse))
        self.btn_psave.draw(surf, hovered=self.btn_psave.rect.collidepoint(mouse))
        self.btn_pload.draw(surf, enabled=has_save(), hovered=self.btn_pload.rect.collidepoint(mouse))
        self.btn_pnew.draw(surf, hovered=self.btn_pnew.rect.collidepoint(mouse))
        if self.power_up:
            self.btn_power.draw(surf, hovered=self.btn_power.rect.collidepoint(mouse))
        self.draw_token_hud(surf)
        self.draw_food_hud(surf)
        self.draw_message_bar(surf)

    def draw_math(self, surf, mouse):
        t = font(48).render("Earn Paw Tokens", True, PINK_D)
        surf.blit(t, t.get_rect(midtop=(W // 2, 20)))
        self.btn_back.draw(surf, hovered=self.btn_back.rect.collidepoint(mouse))
        self.draw_token_hud(surf)
        if self.math_eq is None:
            t = font(26).render("Solve an equation to earn tokens. 2 tries each - miss both and it's game over!", True, SOFT)
            surf.blit(t, t.get_rect(midtop=(W // 2, 84)))
            for i, (desc, reward, _var) in enumerate(MATH_TYPES):
                r = self.math_rects[i]
                hovered = r.collidepoint(mouse)
                rpanel(surf, r, PANEL, PINK if hovered else BORDER, radius=16, width=3 if hovered else 2)
                lines = desc.split("\n")
                y0 = r.y + 26
                for ln in lines:
                    t = font(24).render(ln, True, INK)
                    surf.blit(t, t.get_rect(midtop=(r.centerx, y0)))
                    y0 += 30
                draw_paw(surf, r.right - 74, r.bottom - 34, 1.2)
                t = font(30).render("+%d" % reward, True, (140, 100, 30))
                surf.blit(t, t.get_rect(midtop=(r.right - 58, r.bottom - 48)))
        else:
            lines, answer = self.math_eq
            _, reward, find_var = MATH_TYPES[self.math_kind]
            rpanel(surf, pygame.Rect(230, 110, 500, 340), PANEL, BORDER, radius=18)
            t = font(24).render("Reward: +%d paw token%s" % (reward, "s" if reward != 1 else ""),
                                True, (140, 100, 30))
            surf.blit(t, t.get_rect(midtop=(480, 130)))
            t = font(30).render("Solve for: %s" % find_var, True, PINK_D)
            surf.blit(t, t.get_rect(midtop=(480, 164)))
            y0 = 204
            for ln in lines:
                t = font(58).render(ln, True, INK)
                surf.blit(t, t.get_rect(midtop=(480, y0)))
                y0 += 66
            self.draw_input_box(surf, 355, 330, 250, 54, "type your answer...")
            self.btn_submit.draw(surf, hovered=self.btn_submit.rect.collidepoint(mouse))
            t = font(22).render("Enter works too. Tries left: %d (0 = game over)" % (2 - self.math_tries), True, SOFT)
            surf.blit(t, t.get_rect(midtop=(480, 404)))
        self.draw_message_bar(surf)

    def draw_end(self, surf, mouse, won):
        rpanel(surf, pygame.Rect(180, 120, 600, 320), PANEL, BORDER, radius=18)
        t = font(64).render("You win!" if won else "Game over", True, GREEN_D if won else RED)
        surf.blit(t, t.get_rect(midtop=(W // 2, 160)))
        t = font(26).render(self.end_reason, True, INK)
        surf.blit(t, t.get_rect(midtop=(W // 2, 262)))
        t = font(22).render("Start a new game, or load your last save.", True, SOFT)
        surf.blit(t, t.get_rect(midtop=(W // 2, 330)))
        self.btn_load.draw(surf, enabled=has_save(), hovered=self.btn_load.rect.collidepoint(mouse))
        self.btn_new.draw(surf, hovered=self.btn_new.rect.collidepoint(mouse))
        self.draw_message_bar(surf)

    def draw_box_screen(self, surf, mouse):
        t = font(56).render("Game over", True, RED)
        surf.blit(t, t.get_rect(midtop=(W // 2, 56)))
        t = font(26).render(self.end_reason, True, INK)
        surf.blit(t, t.get_rect(midtop=(W // 2, 132)))
        _, _, color, pattern = self.cat
        mode = "idle" if self.box_alive else "dead"
        draw_cat(surf, W // 2, 360, BOX_CAT_SCALE, color, pattern, mode, self.t, False)
        bx = self.box_x if self.box_x is not None else self.box_rect.centerx
        if bx + self.box_rect.w / 2 > 0:
            self.draw_box(surf, int(bx), self.box_rect.centery,
                          not self.box_flying and self.box_rect.collidepoint(mouse))
        self.draw_bowl(surf, self.bowl_rect.centerx, self.bowl_rect.centery)
        if self.box_flying or self.reveal_left > 0:
            if self.box_alive:
                txt, col = ("Congrats, you opened the box and your cat was alive! "
                            "That was close."), GREEN_D
            else:
                txt, col = "Sorry, you opened the box and your cat was dead.", RED
            t = font(26).render(txt, True, col)
            surf.blit(t, t.get_rect(midtop=(W // 2, 500)))
        else:
            t = font(26).render("Click the box to reveal what's inside...", True, SOFT)
            surf.blit(t, t.get_rect(midtop=(W // 2, 500)))

    def draw_box(self, surf, cx, cy, hover):
        r = pygame.Rect(0, 0, self.box_rect.w, self.box_rect.h)
        r.center = (cx, cy)
        c = (216, 176, 124) if hover else (198, 158, 112)
        edge = (146, 112, 74)
        pygame.draw.rect(surf, c, r, border_radius=8)
        pygame.draw.rect(surf, edge, r, 3, border_radius=8)
        pygame.draw.line(surf, edge, (r.x + 3, r.top + 42), (r.right - 3, r.top + 42), 3)
        tape = pygame.Rect(r.centerx - 22, r.top + 2, 44, r.h - 4)
        pygame.draw.rect(surf, (228, 198, 148), tape)
        pygame.draw.rect(surf, edge, tape, 2)
        t = font(56).render("?", True, edge)
        surf.blit(t, t.get_rect(center=(r.centerx, r.centery + 12)))
        t = hand_font(18).render("50/50", True, edge)
        surf.blit(t, t.get_rect(bottomright=(r.right - 12, r.bottom - 10)))

    def draw_bowl(self, surf, cx, cy):
        body_c = (151, 204, 239)
        edge = (90, 148, 192)
        body = pygame.Rect(0, 0, 130, 54)
        body.center = (cx, cy + 16)
        pygame.draw.ellipse(surf, body_c, body)
        pygame.draw.ellipse(surf, edge, body, 3)
        rim = pygame.Rect(0, 0, 150, 44)
        rim.center = (cx, cy - 14)
        pygame.draw.ellipse(surf, body_c, rim)
        pygame.draw.ellipse(surf, edge, rim, 3)
        inner = pygame.Rect(0, 0, 126, 30)
        inner.center = (cx, cy - 14)
        pygame.draw.ellipse(surf, (196, 228, 248), inner)
        t = hand_font(12).render("Schrodinger's", True, (38, 92, 138))
        surf.blit(t, t.get_rect(center=(cx, cy + 22)))

    def draw_dead(self, surf, mouse):
        _, _, color, pattern = self.cat
        rpanel(surf, pygame.Rect(180, 70, 600, 400), PANEL, BORDER, radius=18)
        t = font(52).render("The cat is dead", True, RED_D)
        surf.blit(t, t.get_rect(midtop=(W // 2, 88)))
        t = font(22).render(self.end_reason, True, INK)
        surf.blit(t, t.get_rect(midtop=(W // 2, 158)))
        draw_cat(surf, W // 2 - 20, 340, 0.9, color, pattern, "dead", self.t, False)
        t = font(22).render("You'll have to start over.", True, SOFT)
        surf.blit(t, t.get_rect(midtop=(W // 2, 430)))
        self.btn_new.draw(surf, hovered=self.btn_new.rect.collidepoint(mouse))

    # ---------- main loop ----------

    def render(self, mouse):
        self.screen.fill(BG)
        if self.state == "shop":
            self.draw_shop(self.screen, mouse)
        elif self.state == "pay":
            self.draw_pay(self.screen, mouse)
        elif self.state == "food":
            self.draw_food(self.screen, mouse)
        elif self.state == "pet":
            self.draw_pet(self.screen, mouse)
        elif self.state == "math":
            self.draw_math(self.screen, mouse)
        elif self.state == "gameover":
            self.draw_box_screen(self.screen, mouse)
        elif self.state == "dead":
            self.draw_dead(self.screen, mouse)
        elif self.state == "win":
            self.draw_end(self.screen, mouse, True)
        if self.paused:
            veil = pygame.Surface((W, H), pygame.SRCALPHA)
            veil.fill((40, 30, 50, 150))
            self.screen.blit(veil, (0, 0))
            t1 = pygame.font.Font(None, 56).render("Pawsed", True, (255, 250, 240))
            self.screen.blit(t1, t1.get_rect(center=(W // 2, H // 2 - 18)))
            t2 = pygame.font.Font(None, 28).render("Press Space to resume",
                                                  True, (235, 225, 205))
            self.screen.blit(t2, t2.get_rect(center=(W // 2, H // 2 + 24)))
        pygame.display.flip()

    async def run(self):
        running = True
        while running:
            dt = min(self.clock.tick(FPS) / 1000.0, 0.1)
            for e in pygame.event.get():
                if not self.handle_event(e):
                    running = False
            if not running:
                break
            self.update(dt)
            self.render(pygame.mouse.get_pos())
            await asyncio.sleep(0)
        pygame.quit()


async def main():
    await Game().run()


if __name__ == "__main__":
    asyncio.run(main())
