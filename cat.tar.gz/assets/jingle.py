"""Completion jingle for the Pawfect Care workspace.

Synthesizes a short bright chime (G5 C6 E6 G6) into jingle.wav on first
run, then plays it through the default sound card and blocks until it
finishes, so it can be run as a one-shot command:

    python3 jingle.py
"""
import math
import os
import time
import wave

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
WAV_PATH = os.path.join(HERE, "jingle.ogg")

SR = 44100


def synth_note(freq, dur):
    t = np.arange(int(SR * dur)) / SR
    tone = (np.sin(2 * math.pi * freq * t)
            + 0.4 * np.sin(2 * math.pi * freq * 2 * t)
            + 0.15 * np.sin(2 * math.pi * freq * 3 * t))
    env = np.exp(-t / (dur / 4.0))
    attack = np.minimum(1.0, t / 0.005)
    return tone * env * attack


def make_jingle():
    notes = [784.0, 1046.5, 1318.5, 1568.0]  # G5 C6 E6 G6
    step = 0.13
    length = step * (len(notes) - 1) + 0.8
    out = np.zeros(int(SR * length))
    for i, freq in enumerate(notes):
        note = synth_note(freq, length - i * step)
        start = int(i * step * SR)
        out[start:start + len(note)] += note
    peak = np.max(np.abs(out))
    if peak > 0:
        out = out / peak * 0.85
    pcm = (np.stack([out, out], axis=1) * 32767).astype("<i2").tobytes()
    with wave.open(WAV_PATH, "wb") as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(pcm)


def play():
    import pygame
    pygame.mixer.init()
    try:
        snd = pygame.mixer.Sound(WAV_PATH)
        snd.play()
        time.sleep(snd.get_length() + 0.15)
    finally:
        pygame.mixer.quit()


if __name__ == "__main__":
    if not os.path.exists(WAV_PATH):
        make_jingle()
    try:
        play()
    except Exception as e:
        print("jingle: could not play sound (%s)" % e)
