"""Visible startup diagnostics for Pawfect Care under pygbag.

Rename this file to main.py. Keep cat_care.py beside it.
Errors appear directly on the game canvas, not only in the Pygbag terminal.
"""
import asyncio
import traceback


def show_status(pygame, screen, heading, lines=(), error=False):
    screen.fill((76, 25, 35) if error else (22, 61, 78))
    font = pygame.font.Font(None, 34)
    small = pygame.font.Font(None, 24)
    title = font.render(heading, True, (255, 245, 200))
    screen.blit(title, (20, 24))
    y = 78
    for line in lines:
        # Split long traceback lines so the right-hand side stays visible.
        for start in range(0, len(line), 100):
            piece = line[start:start + 100]
            image = small.render(piece or " ", True, (255, 255, 255))
            screen.blit(image, (20, y))
            y += 25
            if y > screen.get_height() - 28:
                break
        if y > screen.get_height() - 28:
            break
    pygame.display.flip()


async def main():
    import pygame
    pygame.display.init()
    pygame.font.init()
    screen = pygame.display.set_mode((960, 620))
    pygame.display.set_caption("Pawfect Care - startup diagnostics")
    show_status(pygame, screen, "PAWFECT CARE - STARTUP", ["Step 1: Python and Pygame loaded.", "Loading the game module..."])
    await asyncio.sleep(0)
    try:
        from cat_care import Game
        show_status(pygame, screen, "PAWFECT CARE - STARTUP", ["Step 2: Game module imported.", "Initializing game..."])
        await asyncio.sleep(0)
        game = Game()
        show_status(pygame, game.screen, "PAWFECT CARE - STARTUP", ["Step 3: Game initialized.", "Starting game loop..."])
        await asyncio.sleep(0)
        await game.run()
    except Exception:
        lines = traceback.format_exc().rstrip().splitlines()
        print("PAWFECT CARE STARTUP ERROR:\n" + "\n".join(lines), flush=True)
        # Game may have reset the display. Reacquire it before reporting.
        if not pygame.display.get_init():
            pygame.display.init()
        screen = pygame.display.get_surface()
        if screen is None:
            screen = pygame.display.set_mode((960, 620))
        show_status(pygame, screen, "PAWFECT CARE - PYTHON ERROR", lines[-18:], error=True)
        # Continue yielding so the error remains visible in the browser.
        while True:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    return
            await asyncio.sleep(0.05)


if __name__ == "__main__":
    asyncio.run(main())
