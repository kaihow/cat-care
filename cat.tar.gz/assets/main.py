import asyncio
from cat_care import main

if __name__ == "__main__":
    asyncio.run(main())
