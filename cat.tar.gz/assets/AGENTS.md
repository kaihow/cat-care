# Pawfect Care (cat_care.py)

## Completion jingle

When finished completing a user request in this workspace, run:

    python3 /home/zfarh/zoe/cat/jingle.py

It synthesizes jingle.wav (if missing) and plays a short chime, blocking
until playback finishes.

Rules:
- The jingle must be the LAST action of the turn. Play it only after all
  work (edits, tests, verification) is truly done — never mid-task.
- Play it at most once per user request.
- Do not start new work after playing it.
